<template>
  <div class="tv-safe pb-10 pt-28">
    <h1 class="sr-only">{{ sectionDef.label }} — escolha uma categoria</h1>

    <LoadingState v-if="categories.isLoading.value" message="Carregando categorias…" />

    <ErrorState
      v-else-if="categories.error.value"
      title="Não foi possível carregar as categorias"
      :message="categories.error.value.message"
      :on-retry="categories.refresh"
    />

    <EmptyState
      v-else-if="categories.categories.value.length === 0"
      title="Nenhuma categoria disponível"
      description="Assim que o catálogo for atualizado, as categorias aparecem aqui."
    />

    <ul
      v-else
      class="grid grid-cols-1 gap-4 min-[480px]:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 lg:gap-5 xl:grid-cols-5"
    >
      <li v-for="category in categories.categories.value" :key="category.id">
        <CategoryCard :category="category" :to="`/browse/${section}/${category.slug}`" />
      </li>
    </ul>

    <BrowseHighlights :section="section" class="mt-6 lg:mt-8" />
  </div>
</template>

<script setup lang="ts">
import { SECTIONS, isSectionKey } from '~/constants';

const route = useRoute();

/** Troca de aba (/browse/filmes → /browse/series) remonta a página com a seção nova. */
definePageMeta({ key: (route) => route.fullPath });

const sectionParam = String(route.params.section);
if (!isSectionKey(sectionParam)) {
  throw createError({ statusCode: 404, statusMessage: 'Seção não encontrada', fatal: true });
}

const section = sectionParam;
const sectionDef = SECTIONS[section];

const categories = useCategories();

useHead({ title: computed(() => `Prysma — ${sectionDef.label}`) });
</script>
