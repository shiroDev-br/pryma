/**
 * Identidade visual por categoria (arte de fundo + ícone) para a tela de listagem.
 *
 * O catálogo real traz categorias arbitrárias (Netflix, HBO Max, Novelas, "Series - Animes"…),
 * então a resolução é por palavra-chave no slug. Quando nenhuma regra tem arte própria,
 * o card usa um degradê cinematográfico gerado a partir de um matiz (fixo por marca ou
 * derivado do slug) — cada categoria fica com cor própria e nada quebra.
 *
 * Para trocar a arte por imagens reais, aponte `art` para outro arquivo em /public.
 */
export interface CategoryVisual {
  /** Imagem de fundo em /public. `null` = degradê gerado a partir de `hue`. */
  art: string | null;
  /** Ícone (Iconify) do bloco de vidro. */
  icon: string;
  /** Matiz (0–360) do degradê gerado. */
  hue: number;
}

interface Rule {
  /** Qualquer uma das palavras presente no slug ativa a regra. */
  match: string[];
  art?: string;
  icon: string;
  hue?: number;
}

const art = (name: string) => `/img/categories/${name}.svg`;
const PLAY = 'material-symbols:play-circle-outline-rounded';

/** Ordem importa: regras mais específicas primeiro. */
const RULES: Rule[] = [
  // Gêneros com arte própria
  { match: ['documentar'], art: art('documentarios'), icon: 'material-symbols:description-outline-rounded' },
  { match: ['infantil', 'kids', 'animacao', 'anime', 'desenho'], art: art('infantil'), icon: 'material-symbols:mood-outline-rounded' },
  { match: ['terror'], art: art('terror'), icon: 'material-symbols:skull-outline' },
  { match: ['thriller', 'suspense'], art: art('suspense'), icon: 'material-symbols:search-rounded' },
  { match: ['romance', 'novela'], art: art('romance'), icon: 'material-symbols:favorite-outline-rounded' },
  { match: ['dorama'], art: art('romance'), icon: 'material-symbols:favorite-outline-rounded' },
  { match: ['comedia'], art: art('comedia'), icon: 'material-symbols:sentiment-very-satisfied-outline-rounded' },
  { match: ['acao'], art: art('acao'), icon: 'material-symbols:my-location-outline-rounded' },
  { match: ['faroeste'], art: art('faroeste'), icon: 'mdi:cowboy' },
  { match: ['ficcao'], art: art('ficcao'), icon: 'mdi:planet' },
  { match: ['musica', 'musical', 'show'], art: art('musical'), icon: 'material-symbols:music-note-rounded' },
  { match: ['aventura'], art: art('aventura'), icon: 'material-symbols:explore-outline-rounded' },
  { match: ['esporte'], art: art('esportes'), icon: 'material-symbols:sports-soccer' },
  { match: ['noticia'], art: art('noticias'), icon: 'material-symbols:newspaper' },
  { match: ['culinaria'], art: art('culinaria'), icon: 'material-symbols:restaurant-outline-rounded' },
  { match: ['viagem'], art: art('viagem'), icon: 'material-symbols:flight-outline' },
  { match: ['religio', 'gospel'], art: art('religioso'), icon: 'material-symbols:church-outline' },
  { match: ['drama', 'turca', 'classico'], art: art('drama'), icon: 'material-symbols:theater-comedy-outline-rounded' },
  { match: ['premium'], art: art('premium'), icon: 'material-symbols:workspace-premium-outline-rounded' },

  // Plataformas — degradê na cor da marca
  { match: ['netflix'], icon: PLAY, hue: 355 },
  { match: ['amazon', 'prime'], icon: PLAY, hue: 200 },
  { match: ['hbo'], icon: PLAY, hue: 272 },
  { match: ['disney'], icon: PLAY, hue: 222 },
  { match: ['paramount'], icon: PLAY, hue: 212 },
  { match: ['globoplay', 'globo'], icon: PLAY, hue: 18 },
  { match: ['apple'], icon: PLAY, hue: 240 },
  { match: ['telecine'], icon: PLAY, hue: 340 },
  { match: ['star', 'max', 'discovery', 'crunchyroll', 'pluto'], icon: PLAY, hue: 190 },

  // Formatos / outros
  { match: ['legenda', 'dublad'], icon: 'material-symbols:subtitles-outline-rounded' },
  { match: ['lancamento'], icon: 'material-symbols:new-releases-outline-rounded', hue: 28 },
  { match: ['4k', 'uhd'], icon: 'material-symbols:4k-outline-rounded', hue: 262 },
  { match: ['adulto', 'xxx'], icon: 'material-symbols:lock-outline', hue: 0 },
];

const DEFAULT_ICON = 'material-symbols:movie-outline-rounded';

function hueFromSlug(slug: string): number {
  let hash = 0;
  for (let index = 0; index < slug.length; index += 1) {
    hash = (hash * 31 + slug.charCodeAt(index)) >>> 0;
  }
  // Faixa 195–300: azuis/violetas, coerentes com a identidade do app.
  return 195 + (hash % 105);
}

export function getCategoryVisual(slug: string): CategoryVisual {
  const rule = RULES.find((candidate) => candidate.match.some((word) => slug.includes(word)));
  return {
    art: rule?.art ?? null,
    icon: rule?.icon ?? DEFAULT_ICON,
    hue: rule?.hue ?? hueFromSlug(slug),
  };
}

/** Degradê cinematográfico para categorias sem arte própria. */
export function gradientForHue(hue: number): string {
  const h2 = (hue + 38) % 360;
  return [
    `radial-gradient(46% 52% at 82% 22%, hsl(${hue} 78% 52% / 0.8), transparent 72%)`,
    `radial-gradient(60% 70% at 12% 100%, hsl(${h2} 70% 38% / 0.65), transparent 72%)`,
    `radial-gradient(18% 24% at 62% 62%, hsl(${hue} 85% 70% / 0.28), transparent 100%)`,
    `radial-gradient(10% 14% at 90% 78%, hsl(${h2} 85% 72% / 0.3), transparent 100%)`,
    `linear-gradient(160deg, hsl(${hue} 55% 16%) 0%, #03060f 100%)`,
  ].join(', ');
}
