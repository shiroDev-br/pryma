import type { MediaQuality } from '~/types';

/** Posição na lista -> "001", "012", "891". */
export function channelNumber(position: number): string {
  return String(position).padStart(3, '0');
}

const QUALITY_BADGES: Record<MediaQuality, string> = {
  '4K': '4K',
  '1080p': 'FHD',
  '720p': 'HD',
  '480p': 'SD',
};

/** Selo de qualidade do canal (HD, FHD, 4K…). Sem dado: null. */
export function qualityBadge(quality: MediaQuality | null | undefined): string | null {
  return quality ? QUALITY_BADGES[quality] : null;
}

/** "Globo News HD" -> "GN" — fallback quando o canal não tem logo. */
export function channelInitials(title: string): string {
  return (
    title
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((word) => word[0]?.toUpperCase() ?? '')
      .join('') || 'TV'
  );
}

/** Epoch ms -> "20:22" (fuso do aparelho). */
export function formatHourMinute(timestamp: number): string {
  return new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit' }).format(
    new Date(timestamp),
  );
}
