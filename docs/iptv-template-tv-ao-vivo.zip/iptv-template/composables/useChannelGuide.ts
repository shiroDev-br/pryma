import { computed, onBeforeUnmount, onMounted, ref, shallowRef, toValue, watch } from 'vue';
import type { MaybeRefOrGetter } from 'vue';
import type { GuideProgram } from '~/types';

/**
 * Fonte da programação (EPG) de um canal.
 *
 * A API atual não expõe grade de programação, e as diretrizes do projeto proíbem
 * inventar dados — então devolve vazio e a UI mostra "Programação indisponível".
 * Quando o backend tiver o endpoint, é só implementar aqui (retornar `GuideProgram[]`);
 * painel, barra de progresso e lista já reagem sozinhos.
 */
async function fetchGuide(_channelId: string): Promise<GuideProgram[]> {
  return [];
}

const TICK_MS = 30_000;
const UPCOMING_LIMIT = 4;

interface TimedProgram extends GuideProgram {
  start: number;
  end: number;
}

export function useChannelGuide(channelId: MaybeRefOrGetter<string | null>) {
  const programs = shallowRef<TimedProgram[]>([]);
  const now = ref(Date.now());
  let requestId = 0;
  let timer: ReturnType<typeof setInterval> | undefined;

  watch(
    () => toValue(channelId),
    async (id) => {
      const current = ++requestId;
      programs.value = [];
      if (!id || import.meta.server) return;

      try {
        const list = await fetchGuide(id);
        if (current !== requestId) return;
        programs.value = list
          .map((program) => ({
            ...program,
            start: Date.parse(program.startsAt),
            end: Date.parse(program.endsAt),
          }))
          .filter((program) => Number.isFinite(program.start) && Number.isFinite(program.end))
          .sort((a, b) => a.start - b.start);
      } catch {
        if (current === requestId) programs.value = [];
      }
    },
    { immediate: true },
  );

  onMounted(() => {
    now.value = Date.now();
    timer = setInterval(() => {
      now.value = Date.now();
    }, TICK_MS);
  });

  onBeforeUnmount(() => clearInterval(timer));

  const current = computed(
    () => programs.value.find((program) => program.start <= now.value && now.value < program.end) ?? null,
  );

  const upcoming = computed(() =>
    programs.value.filter((program) => program.start > now.value).slice(0, UPCOMING_LIMIT),
  );

  /** Programa atual + próximos — a lista "Programação". */
  const schedule = computed(() => (current.value ? [current.value, ...upcoming.value] : upcoming.value));

  /** 0–1 — quanto do programa atual já passou. */
  const progress = computed(() => {
    const program = current.value;
    if (!program) return 0;
    return Math.min(1, Math.max(0, (now.value - program.start) / (program.end - program.start)));
  });

  const remainingMinutes = computed(() => {
    const program = current.value;
    return program ? Math.max(0, Math.ceil((program.end - now.value) / 60_000)) : 0;
  });

  return { current, upcoming, schedule, progress, remainingMinutes };
}
