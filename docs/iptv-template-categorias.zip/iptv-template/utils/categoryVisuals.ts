/**
 * Identidade visual por categoria (arte de fundo + ícone) para a tela de listagem.
 * Chave = slug da categoria (mesma regra de `sanitizeSlug`). Slugs desconhecidos
 * (catálogo real da API) caem no visual padrão — nunca quebram a tela.
 *
 * Para trocar a arte por imagens reais, basta apontar `art` para outro arquivo
 * (ex.: `/img/categories/acao.jpg`) — o componente não muda.
 */
export interface CategoryVisual {
  /** Caminho em /public da imagem de fundo do card. */
  art: string;
  /** Ícone (Iconify) exibido no bloco de vidro do card. */
  icon: string;
}

const art = (name: string) => `/img/categories/${name}.svg`;

const DEFAULT_VISUAL: CategoryVisual = {
  art: art('cinema'),
  icon: 'material-symbols:movie-outline-rounded',
};

const VISUALS: Record<string, CategoryVisual> = {
  acao: { art: art('acao'), icon: 'material-symbols:my-location-outline-rounded' },
  animacao: { art: art('infantil'), icon: 'material-symbols:brush-outline-rounded' },
  aventura: { art: art('aventura'), icon: 'material-symbols:explore-outline-rounded' },
  'cinema-hd': { art: art('cinema'), icon: 'material-symbols:hd-outline-rounded' },
  classicos: { art: art('drama'), icon: 'material-symbols:local-movies-outline' },
  comedia: { art: art('comedia'), icon: 'material-symbols:sentiment-very-satisfied-outline-rounded' },
  culinaria: { art: art('culinaria'), icon: 'material-symbols:restaurant-outline-rounded' },
  documentarios: { art: art('documentarios'), icon: 'material-symbols:description-outline-rounded' },
  drama: { art: art('drama'), icon: 'material-symbols:theater-comedy-outline-rounded' },
  esportes: { art: art('esportes'), icon: 'material-symbols:sports-soccer' },
  'esportes-24h': { art: art('esportes'), icon: 'material-symbols:sports-soccer' },
  faroeste: { art: art('faroeste'), icon: 'mdi:cowboy' },
  'ficcao-cientifica': { art: art('ficcao'), icon: 'mdi:planet' },
  'filmes-nacionais': { art: art('cinema'), icon: 'material-symbols:flag-outline-rounded' },
  infantil: { art: art('infantil'), icon: 'material-symbols:mood-outline-rounded' },
  'infantil-premium': { art: art('infantil'), icon: 'material-symbols:mood-outline-rounded' },
  lancamentos: { art: art('cinema'), icon: 'material-symbols:new-releases-outline-rounded' },
  musica: { art: art('musical'), icon: 'material-symbols:music-note-rounded' },
  musicais: { art: art('musical'), icon: 'material-symbols:music-note-rounded' },
  noticias: { art: art('noticias'), icon: 'material-symbols:newspaper' },
  premium: { art: art('premium'), icon: 'material-symbols:workspace-premium-outline-rounded' },
  'reality-shows': { art: art('musical'), icon: 'material-symbols:videocam-outline-rounded' },
  religioso: { art: art('religioso'), icon: 'material-symbols:church-outline' },
  romance: { art: art('romance'), icon: 'material-symbols:favorite-outline-rounded' },
  series: { art: art('cinema'), icon: 'material-symbols:tv-gen-outline-rounded' },
  suspense: { art: art('suspense'), icon: 'material-symbols:search-rounded' },
  terror: { art: art('terror'), icon: 'material-symbols:skull-outline' },
  viagem: { art: art('viagem'), icon: 'material-symbols:flight-outline' },
};

export function getCategoryVisual(slug: string): CategoryVisual {
  return VISUALS[slug] ?? DEFAULT_VISUAL;
}
