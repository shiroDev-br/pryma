<template>
  <nav aria-label="Seções do catálogo">
    <ul class="grid grid-cols-3 gap-3 sm:gap-4 lg:grid-cols-5 lg:gap-5">
      <li v-for="tab in tabs" :key="tab.key">
        <NuxtLink
          :to="`/browse/${tab.key}`"
          class="section-tab flex h-14 items-center justify-center gap-2.5 rounded-lg border px-3 text-[0.95rem] font-semibold transition-colors duration-fast focus:outline-none focus-visible:shadow-focus"
          :class="
            tab.key === current
              ? 'section-tab--active text-ink'
              : 'border-white/10 bg-[#06142d]/60 text-ink-muted hover:border-white/25 hover:text-ink'
          "
          :aria-current="tab.key === current ? 'page' : undefined"
        >
          <Icon :name="tab.icon" class="h-5 w-5 shrink-0" aria-hidden="true" />
          <span class="truncate">{{ tab.label }}</span>
        </NuxtLink>
      </li>
    </ul>
  </nav>
</template>

<script setup lang="ts">
import { SECTIONS } from '~/constants';
import type { SectionKey } from '~/constants';

defineProps<{
  current: SectionKey;
}>();

const tabs = (Object.keys(SECTIONS) as SectionKey[]).map((key) => ({
  key,
  label: SECTIONS[key].label,
  icon: SECTIONS[key].icon,
}));
</script>

<style scoped>
/* Aba ativa: borda em degradê violeta → azul sobre fundo navy. */
.section-tab--active {
  border-color: transparent;
  background:
    linear-gradient(#071530, #071530) padding-box,
    linear-gradient(90deg, var(--color-accent), var(--color-blue)) border-box;
  box-shadow: 0 0 28px rgba(124, 92, 255, 0.22);
}
</style>
