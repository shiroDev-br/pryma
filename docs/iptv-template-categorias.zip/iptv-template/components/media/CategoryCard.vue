<template>
  <NuxtLink
    :to="to"
    class="category-card group relative block aspect-[3/2] overflow-hidden rounded-lg border border-white/10 bg-surface transition-[transform,border-color,box-shadow] duration-normal hover:-translate-y-0.5 hover:border-accent/60 hover:shadow-card focus:outline-none focus-visible:border-accent focus-visible:shadow-focus"
  >
    <!-- Arte de fundo -->
    <img
      :src="visual.art"
      alt=""
      loading="lazy"
      decoding="async"
      aria-hidden="true"
      class="absolute inset-0 h-full w-full object-cover transition-transform duration-slow ease-stage group-hover:scale-[1.06]"
    />

    <!-- Escurecimento para legibilidade do texto -->
    <div
      class="absolute inset-0 bg-gradient-to-t from-[#020817]/90 via-[#020817]/35 to-[#020817]/5"
      aria-hidden="true"
    />

    <div class="relative flex h-full flex-col justify-end gap-3.5 p-5">
      <span
        class="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border border-white/15 bg-[#050b1c]/70 text-ink shadow-[0_8px_24px_rgba(0,0,0,0.45)] backdrop-blur-md"
        aria-hidden="true"
      >
        <Icon :name="visual.icon" class="h-7 w-7" />
      </span>

      <span class="flex items-end justify-between gap-3">
        <span class="min-w-0">
          <span class="block truncate text-[1.15rem] font-semibold leading-tight text-ink">
            {{ category.name }}
          </span>
          <span class="mt-1 block text-[0.9rem] tabular-nums text-ink-muted">
            {{ countLabel }}
          </span>
        </span>

        <Icon
          name="material-symbols:chevron-right-rounded"
          class="mb-1 h-7 w-7 shrink-0 text-ink transition-transform duration-fast group-hover:translate-x-0.5"
          aria-hidden="true"
        />
      </span>
    </div>
  </NuxtLink>
</template>

<script setup lang="ts">
import { getCategoryVisual } from '~/utils/categoryVisuals';
import type { Category } from '~/types';

const props = defineProps<{
  category: Category;
  to: string;
}>();

const visual = computed(() => getCategoryVisual(props.category.slug));

const countFormatter = new Intl.NumberFormat('pt-BR');

const countLabel = computed(() => {
  const count = props.category.itemCount;
  return `${countFormatter.format(count)} ${count === 1 ? 'título' : 'títulos'}`;
});
</script>
