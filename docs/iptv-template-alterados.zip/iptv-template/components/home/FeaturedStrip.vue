<template>
  <section
    class="featured relative overflow-hidden rounded-2xl border border-white/[0.1]"
    aria-label="Em destaque"
  >
    <!-- Montanha ao fundo — o mesmo cenário do plano de fundo, bem discreto. -->
    <div class="featured__scene pointer-events-none absolute inset-0" aria-hidden="true" />

    <div
      class="relative grid items-center gap-y-5 px-6 py-5 sm:px-8 lg:grid-cols-[minmax(13rem,1.25fr)_repeat(5,minmax(0,1fr))] lg:gap-y-0"
    >
      <!-- Título -->
      <div class="lg:pr-6">
        <p class="flex items-center gap-2 text-[0.62rem] font-semibold uppercase tracking-[0.24em] text-ink-muted">
          <Icon name="material-symbols:star-rounded" class="h-4 w-4 text-blue" aria-hidden="true" />
          Em destaque
        </p>
        <p class="mt-2 text-[clamp(1.15rem,1.75vw,1.55rem)] font-bold leading-[1.15] text-ink">
          Conteúdo para<br />
          <span class="text-blue">todos os gostos.</span>
        </p>
      </div>

      <!-- Números -->
      <ul class="contents">
        <li
          v-for="stat in stats"
          :key="stat.label"
          class="stat flex flex-col items-center text-center lg:h-full lg:justify-center lg:border-l lg:border-white/10 lg:px-3"
        >
          <span
            class="flex h-12 w-12 items-center justify-center rounded-full border border-blue/25 bg-[#0a1f45]/70 text-blue shadow-[0_0_18px_rgba(22,136,255,0.18)]"
            aria-hidden="true"
          >
            <Icon :name="stat.icon" class="h-6 w-6" />
          </span>
          <span class="mt-2.5 text-[0.82rem] font-semibold leading-tight text-ink">
            {{ stat.value }}
          </span>
          <span class="mt-0.5 text-[0.72rem] leading-tight text-ink-muted">{{ stat.label }}</span>
        </li>
      </ul>
    </div>
  </section>
</template>

<script setup lang="ts">
interface Stat {
  icon: string;
  value: string;
  label: string;
}

/** Texto institucional da home — números de divulgação, não vêm da API. */
const stats: Stat[] = [
  { icon: 'material-symbols:live-tv-outline-rounded', value: '+ de 12.000', label: 'Canais' },
  { icon: 'material-symbols:movie-filter-outline', value: '+ de 20.000', label: 'Filmes' },
  { icon: 'material-symbols:movie-outline-rounded', value: '+ de 8.000', label: 'Séries' },
  { icon: 'material-symbols:child-care-outline-rounded', value: 'Canais Kids', label: 'e Adultos' },
  { icon: 'material-symbols:devices', value: 'Em todos os seus', label: 'dispositivos' },
];
</script>

<style scoped>
.featured {
  background:
    linear-gradient(180deg, rgba(10, 24, 54, 0.78) 0%, rgba(3, 9, 24, 0.9) 100%);
  backdrop-filter: blur(14px);
  box-shadow: 0 18px 50px rgba(0, 0, 0, 0.45);
}

.featured__scene {
  background-image:
    linear-gradient(90deg, rgba(3, 9, 24, 0.96) 0%, rgba(3, 9, 24, 0.55) 55%, rgba(3, 9, 24, 0.2) 100%),
    url('/img/mountain.jpg');
  background-size: cover;
  background-position: 70% 28%;
  opacity: 0.55;
  mix-blend-mode: screen;
  filter: saturate(0.8) brightness(0.7);
}
</style>
