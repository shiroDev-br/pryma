import { computed } from 'vue';

/** Item do menu principal da home — destinos que existem de fato no app. */
export interface HomeMenuItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  to: string;
  /** Imagem de fundo do card (asset em `public/img/cards/`). */
  image?: string;
  /** Contagem exibida como badge — só quando o dado existe. */
  meta?: string;
  /** Texto mais longo mostrado quando o card está em foco (cai em `description` se ausente). */
  longDescription?: string;
}

/**
 * Os cinco destinos de primeira camada da home.
 * Lançamentos, catálogo e categorias continuam acessíveis pelas telas próprias.
 */
const SECTION_ITEMS: Omit<HomeMenuItem, 'to' | 'meta'>[] = [
  {
    id: 'channels',
    title: 'Canais',
    description: 'Todos os canais em um só lugar.',
    icon: 'material-symbols:grid-view-outline-rounded',
    image: '/img/cards/canais.svg',
  },
  {
    id: 'movies',
    title: 'Filmes',
    description: 'Lançamentos, clássicos e muito mais.',
    icon: 'material-symbols:movie-outline-rounded',
    image: '/img/cards/filmes.svg',
  },
  {
    id: 'plans',
    title: 'Planos',
    description: 'Escolha o plano ideal para você.',
    longDescription: 'Escolha o plano ideal para você e tenha acesso a todo o conteúdo.',
    icon: 'prysma:plans',
    image: '/img/cards/planos.svg',
  },
  {
    id: 'series',
    title: 'Séries',
    description: 'Suas séries favoritas, sempre disponíveis.',
    icon: 'material-symbols:tv-gen-outline-rounded',
    image: '/img/cards/series.svg',
  },
  {
    id: 'animation',
    title: 'Animação',
    description: 'O melhor da animação para todas as idades.',
    icon: 'prysma:bear',
    image: '/img/cards/animacao.svg',
  },
];

/** Rotas fixas — a animação recebe o slug real da categoria quando ele existe. */
const SECTION_ROUTES: Record<string, string> = {
  channels: '/medias?type=live',
  movies: '/medias?type=vod',
  plans: '/pricing',
  series: '/medias?type=series',
};

export interface HomeMenu {
  items: ComputedRef<HomeMenuItem[]>;
  isLoading: ComputedRef<boolean>;
  error: Ref<Error | null>;
  refresh: () => Promise<void>;
}

/**
 * Menu da home — cinco destinos fixos. O item de animação aponta para a
 * categoria real vinda da camada de dados; sem slug conhecido, cai no catálogo.
 * Nenhum dado é inventado.
 */
export function useHomeMenu(): HomeMenu {
  const categories = useCategories();

  const animationTo = computed(() => {
    const category = categories.categories.value.find(
      (item) => /animac/.test(item.slug) || /^anima/i.test(item.name),
    );
    return category ? `/medias?category=${encodeURIComponent(category.slug)}` : '/medias';
  });

  const items = computed<HomeMenuItem[]>(() =>
    SECTION_ITEMS.map((item) => ({
      ...item,
      to: item.id === 'animation' ? animationTo.value : SECTION_ROUTES[item.id] ?? '/medias',
    })),
  );

  return {
    items,
    isLoading: categories.isLoading,
    error: categories.error,
    refresh: categories.refresh,
  };
}
