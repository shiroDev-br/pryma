<template>
  <div class="relative flex min-h-[100svh] flex-col text-ink">
    <AppBackground />
    <AppSidebar />
    <AppHeader />
    <!-- Acima de `lg` a sidebar fixa ocupa a esquerda; o conteúdo recua por `--sidebar-w`. -->
    <main class="flex-1 lg:pl-[var(--sidebar-w)]">
      <slot />
    </main>
  </div>
</template>
