<template>
  <div class="isolate flex min-h-[100svh] flex-col pb-6 lg:pb-8">
    <h1 class="sr-only">Prysma — TV ao vivo, filmes e séries</h1>

    <!-- Identidade/saudação — bloco leve no topo, o destaque é o carrossel. -->
    <div class="tv-safe pt-24 sm:pt-28">
      <p v-if="greeting" class="text-[clamp(1rem,1.45vw,1.3rem)] font-light text-ink-muted">
        {{ greeting }},
      </p>
      <p class="mt-1 text-[clamp(1.8rem,2.9vw,2.6rem)] font-bold leading-tight text-ink">
        Seja <span class="text-blue">bem-vindo!</span>
      </p>
      <p class="mt-3 max-w-[22rem] text-[0.88rem] leading-relaxed text-ink-muted">
        Explore nossos conteúdos e aproveite uma experiência única.
      </p>
    </div>

    <!-- Carrossel cinematográfico — cinco destinos, card central em destaque. -->
    <div class="flex flex-1 items-center pt-4 lg:pt-8">
      <HomeCarousel
        class="w-full"
        :items="menu.items.value"
        :is-loading="menu.isLoading.value"
        :error="menu.error.value"
        :on-retry="menu.refresh"
      />
    </div>

    <!-- Faixa institucional inferior. -->
    <div class="tv-safe mt-4 pb-20 lg:pb-0">
      <FeaturedStrip />
    </div>

    <!-- Navegação rápida inferior — só sem sidebar (< lg). -->
    <HomeNavigationBar />
  </div>
</template>

<script setup lang="ts">
useHead({ title: 'Prysma — Início' });

const menu = useHomeMenu();

const greeting = ref('');

// Saudação por horário — só no cliente para não divergir do SSR.
// Madrugada e noite → "Boa noite" (a referência mostra 00:12 com "Boa noite").
onMounted(() => {
  const hour = new Date().getHours();
  greeting.value = hour >= 5 && hour < 12 ? 'Bom dia' : hour >= 12 && hour < 18 ? 'Boa tarde' : 'Boa noite';
});
</script>
