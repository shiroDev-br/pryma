<template>
  <div ref="root" class="live-screen tv-safe pb-6 pt-24" @keydown="onKeydown">
    <!-- Fundo liso (sem a montanha) — a tela de canais é densa e precisa de contraste. -->
    <div class="bg-ambient fixed inset-0 -z-[5]" aria-hidden="true" />

    <h1 class="sr-only">TV ao Vivo — todos os canais</h1>

    <LoadingState
      v-if="categories.isLoading.value && tvCategories.length === 0"
      message="Carregando canais…"
    />

    <ErrorState
      v-else-if="categories.error.value"
      title="Não foi possível carregar os canais"
      :message="categories.error.value.message"
      :on-retry="categories.refresh"
    />

    <!-- 2 colunas: lista de grupos/canais (esquerda) + prévia com programação (direita).
         Os breakpoints do Tailwind aqui valem 0px (layout único, escalado pelo rem). -->
    <div
      v-else
      class="grid h-[calc(var(--app-vh)_-_7.5rem)] min-h-[30rem] grid-cols-1 gap-5 lg:grid-cols-[minmax(18rem,0.9fr)_minmax(0,1.1fr)] xl:grid-cols-[minmax(22rem,0.85fr)_minmax(0,1.15fr)] xl:gap-6"
    >
      <!-- Coluna 1: voltar + busca + grupos expansíveis com os canais -->
      <LiveChannelsSidebar
        ref="sidebar"
        v-model:query="search.search.query.value"
        :pool="sidebarPool"
        :categories="tvCategories"
        :active-slug="activeSlug"
        :label="groupLabel"
        :count="total"
        :selected-id="selected?.id ?? null"
        :loading="source.isPending.value"
        :error="source.error.value?.message ?? ''"
        @clear="search.search.clear()"
        @select="setCategory"
        @pick="pickChannel"
        @play="playChannel"
        @preview="preview"
        @back="goBack"
        @retry="source.refresh"
      />

      <!-- Coluna 2: prévia + programação -->
      <LiveChannelPreview
        class="flex"
        :paused="leaving"
        :media="selected"
        :category-slug="selected?.categoryId ? (categoryById.get(selected.categoryId)?.slug ?? null) : null"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { DEFAULT_PAGE_SIZE, SECTIONS } from '~/constants';
import { getRepositories } from '~/repositories';
import { useSearchResults } from '~/composables/useSearchResults';
import { usePaginatedQuery } from '~/composables/usePaginatedQuery';
import type { PaginatedQuery } from '~/composables/usePaginatedQuery';
import { categoryBelongsToSection } from '~/utils/categorySections';
import { isAdultCategory, isAdultItem } from '~/utils/adult';
import { mediaHref } from '~/utils/media';
import type { MediaQuery, MediaSummary } from '~/types';
import LiveChannelsSidebar from './LiveChannelsSidebar.vue';

useHead({ title: `Pryma — ${SECTIONS.tv.label}` });

const root = ref<HTMLElement | null>(null);
/** Instância da coluna 1 — rolagem, foco e sentinela do infinite scroll. */
const sidebar = ref<InstanceType<typeof LiveChannelsSidebar> | null>(null);

/* ── Categorias ────────────────────────────────────────────────────────── */

const categories = useCategories();

/** Conteúdo adulto oculto — desbloqueio futuro (flag fica pronta, nunca vem do servidor). */
const adultUnlocked = useState<boolean>('adult.unlocked', () => false);

const tvCategories = computed(() =>
  categories.categories.value.filter(
    (category) =>
      categoryBelongsToSection(category.slug, 'tv') &&
      (adultUnlocked.value || !isAdultCategory(category.slug)),
  ),
);

const categoryById = computed(
  () => new Map(categories.categories.value.map((category) => [category.id, category])),
);

/** Slugs especiais — filtram por nome via busca no servidor. */
const SPECIAL_TAB_SLUGS = ['__premiere__', '__espn__', '__sportv__'] as const;
type SpecialTabSlug = (typeof SPECIAL_TAB_SLUGS)[number];

function isSpecialSlug(slug: string): slug is SpecialTabSlug {
  return (SPECIAL_TAB_SLUGS as readonly string[]).includes(slug);
}

/* ── Estado persistido (sobrevive a ida ao player e à volta) ───────────── */

const liveState = useState('live.tvState', () => ({
  activeSlug: '' as string,
  selectedId: null as string | null,
  /** Texto da busca — volta junto com a lista. */
  query: '' as string,
  /** true só quando saímos pro player: a volta restaura a posição. Qualquer outra saída zera. */
  returning: false,
}));

/** Entrou na tela vindo do player? Decidido antes de qualquer render. */
const cameBackFromPlayer = liveState.value.returning;
liveState.value.returning = false;

/** Entrada "limpa" (home → TV ao vivo): estado zerado, começa no topo. */
if (!cameBackFromPlayer) {
  liveState.value.activeSlug = '';
  liveState.value.selectedId = null;
  liveState.value.query = '';
}

/** Slug ativo — vazio é "Todos". */
const activeSlug = computed(() => liveState.value.activeSlug);

const activeCategory = computed(
  () => tvCategories.value.find((category) => category.slug === activeSlug.value) ?? null,
);

function setCategory(slug: string): void {
  liveState.value.activeSlug = slug;
}

function goBack(): void {
  // Com grupo filtrado, o voltar primeiro limpa o filtro (volta pra "Todos").
  if (activeSlug.value) {
    setCategory('');
    return;
  }
  navigateTo('/');
}

/* ── Dados ─────────────────────────────────────────────────────────────── */

const mediaParams = computed<MediaQuery>(() => {
  const params: MediaQuery = { type: 'live', limit: DEFAULT_PAGE_SIZE };
  // Slugs especiais não são categorias reais — não mandar pra API.
  if (activeSlug.value && !isSpecialSlug(activeSlug.value)) params.category = activeSlug.value;
  return params;
});

const mediaList = useMediaList(mediaParams);
const search = useSearchResults({ type: 'live', initialQuery: liveState.value.query });

watch(search.search.query, (value) => {
  liveState.value.query = value;
});

// SSR: a tela sai com os primeiros canais no HTML.
await mediaList.ready;

const searching = computed(() => search.search.isReady.value);

/** Busca fixa por termo — carrega os canais dos grupos especiais no servidor
 *  (ficam fora da primeira página paginada; filtrar client-side não alcança). */
function fixedLiveSearch(term: string): PaginatedQuery<MediaSummary> {
  const repository = getRepositories().media;
  return usePaginatedQuery<MediaSummary>(
    (cursor, signal) =>
      repository.search({ q: term, cursor, type: 'live', limit: 50 }, { signal }),
  );
}

const specialLists: Record<SpecialTabSlug, PaginatedQuery<MediaSummary>> = {
  __premiere__: fixedLiveSearch('premiere'),
  __espn__: fixedLiveSearch('espn'),
  __sportv__: fixedLiveSearch('sportv'),
};

/** Fonte da lista: busca do usuário > grupo especial (busca por termo) > listagem paginada. */
const source = computed(() => {
  if (searching.value) return search;
  const slug = activeSlug.value;
  if (isSpecialSlug(slug)) return specialLists[slug];
  return mediaList;
});

/** Canais visíveis — sempre em ordem alfabética. Adulto fica de fora até desbloquear. */
const channels = computed<MediaSummary[]>(() => {
  const category = activeCategory.value;
  const items = source.value.items.value;
  const filtered = (!searching.value || !category)
    ? items
    : items.filter((item) => item.categoryId === category.id);

  const visible = adultUnlocked.value
    ? filtered
    : filtered.filter((item) => !isAdultItem(item));

  return [...visible].sort((a, b) => a.title.localeCompare(b.title, 'pt-BR'));
});

/** Pool da sidebar — união da listagem principal + buscas especiais (sem duplicatas).
 *  Garante que Premiere/ESPN/SportTV apareçam mesmo fora da primeira página. */
const sidebarPool = computed<MediaSummary[]>(() => {
  const base = searching.value ? channels.value : mediaList.items.value;
  const byId = new Map<string, MediaSummary>();
  for (const item of base) byId.set(item.id, item);
  if (!searching.value) {
    for (const list of Object.values(specialLists)) {
      for (const item of list.items.value) byId.set(item.id, item);
    }
  }
  const all = [...byId.values()];
  return adultUnlocked.value ? all : all.filter((item) => !isAdultItem(item));
});

const total = computed(() =>
  searching.value && activeCategory.value ? channels.value.length : source.value.total.value,
);

const groupLabel = computed(() => {
  if (searching.value) return 'Resultados';
  if (activeSlug.value === '__premiere__') return 'Premiere';
  if (activeSlug.value === '__espn__') return 'ESPN';
  if (activeSlug.value === '__sportv__') return 'SportTV';
  return activeCategory.value?.name ?? 'Todos';
});

/* ── Seleção (prévia da direita) ───────────────────────────────────────── */

const selectedId = ref<string | null>(liveState.value.selectedId);

const selected = computed<MediaSummary | null>(() => {
  const id = selectedId.value;
  const chosen = id
    ? (sidebarPool.value.find((channel) => channel.id === id)
      ?? channels.value.find((channel) => channel.id === id))
    : null;
  return chosen ?? channels.value[0] ?? null;
});

/** Atraso curto antes de trocar a prévia: segurar a seta passa por muitos
 *  canais por segundo e cada troca remonta a arte e a programação do canal —
 *  sem debounce a coluna da direita re-renderiza a cada item e a TV trava. */
let previewTimer: ReturnType<typeof setTimeout> | undefined;

function preview(channel: MediaSummary): void {
  if (previewTimer) clearTimeout(previewTimer);
  previewTimer = setTimeout(() => {
    selectedId.value = channel.id;
    liveState.value.selectedId = channel.id;
  }, 80);
}

/* ── Navegação por setas (teclado / controle remoto) ───────────────────── */

const { onKeydown } = useLiveNav({
  root,
  selectedId: () => selected.value?.id ?? null,
});

/** Clique na guia de um canal: seleciona e leva a coluna até ele. */
function pickChannel(channel: MediaSummary): void {
  preview(channel);
  sidebar.value?.revealChannel(channel.id);
}

/** Derruba a prévia ao vivo antes de abrir o player (limite de conexões do provedor). */
const leaving = ref(false);

/** Clique numa transmissão: vai direto pro player. */
function playChannel(channel: MediaSummary): void {
  leaving.value = true;
  selectedId.value = channel.id;
  liveState.value.selectedId = channel.id;
  navigateTo(mediaHref(channel));
}

/* ── Rolagem infinita (a sidebar é a única lista) ──────────────────────── */

function loadMoreIfVisible(isIntersecting: boolean): void {
  if (isIntersecting) source.value.loadMore();
}

useIntersectionObserver(() => sidebar.value?.sentinel() ?? null, loadMoreIfVisible);

// Trocou filtro/busca: volta ao topo da coluna.
watch([activeSlug, () => search.search.normalizedQuery.value], async () => {
  await nextTick();
  sidebar.value?.resetScroll();
});

/* ── Entrada / saída da tela ───────────────────────────────────────────── */

/** Volta do player: carrega páginas até achar o canal, expande o grupo e foca. */
async function restoreAfterPlayer(): Promise<void> {
  const id = liveState.value.selectedId;
  if (id) {
    let guard = 0;
    while (!sidebar.value?.hasChannel(id) && source.value.hasNext.value && guard++ < 80) {
      if (source.value.isLoading.value) {
        await new Promise((resolve) => setTimeout(resolve, 60));
      } else {
        await source.value.loadMore();
      }
      await nextTick();
    }
    if (await sidebar.value?.focusChannel(id)) return;
  }
  // Canal não existe mais na lista: cai no comportamento de entrada limpa.
  sidebar.value?.focusFirst();
}

onMounted(() => {
  if (cameBackFromPlayer) {
    void restoreAfterPlayer();
  } else {
    // Entrada limpa: foco no primeiro item da coluna da esquerda (canto superior esquerdo).
    sidebar.value?.focusFirst();
  }
});

const router = useRouter();

onBeforeUnmount(() => {
  if (previewTimer) clearTimeout(previewTimer);

  // Só preserva o estado se o destino for o player; qualquer outra saída
  // (home, busca, etc.) faz a próxima entrada começar do início.
  // `router.currentRoute` já aponta pro destino neste momento.
  const goingToPlayer = router.currentRoute.value.path.startsWith('/medias/');
  liveState.value.returning = goingToPlayer;
  if (goingToPlayer) {
    liveState.value.selectedId = selectedId.value ?? liveState.value.selectedId;
  }
});
</script>
