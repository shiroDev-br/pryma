import { onBeforeUnmount, onMounted, ref, watch } from 'vue';
import type { Ref } from 'vue';
// Só tipos — hls.js/mpegts.js entram por import dinâmico (mesmo chunk do player).
import type Hls from 'hls.js';
import type mpegts from 'mpegts.js';
import { usePlayback } from '~/composables/usePlayback';

/** Tempo parado no mesmo canal antes de abrir o stream. Segurar a seta passa
 *  por muitos canais por segundo — sem isso cada um abriria (e mataria) uma conexão. */
const DWELL_MS = 700;
/** Sem imagem em 9s: desiste e fica só com a arte (nada de loop de retry). */
const STALL_MS = 12000;

export interface UseLivePreviewOptions {
  /** <video> da prévia — um só, reaproveitado entre canais. */
  videoEl: Ref<HTMLVideoElement | null>;
  /** Canal em foco (null = nada tocando). */
  mediaId: () => string | null;
  /** false pausa e derruba o stream (ex.: saindo pro player). */
  enabled: () => boolean;
}

export type LivePreviewState = 'idle' | 'waiting' | 'loading' | 'playing' | 'failed';

export interface UseLivePreviewReturn {
  /** true quando já tem imagem rodando — a prévia faz o fade da arte pro vídeo. */
  playing: Ref<boolean>;
  /** Estado detalhado (diagnóstico) e o motivo da última falha. */
  state: Ref<LivePreviewState>;
  reason: Ref<string>;
  /** Handlers do <video> — ligados no template pra sobreviver a v-if/troca de elemento. */
  onPlaying: () => void;
  onTimeUpdate: () => void;
  onVideoError: () => void;
  /** Derruba o stream agora (ex.: clique em "Assistir", pra não ter 2 conexões abertas). */
  stop: () => void;
}

/**
 * Prévia ao vivo, leve, da coluna da direita da TV ao vivo.
 *
 * Diferenças do player de verdade (useStreamEngine), de propósito:
 *  - mudo, sem controles, sem áudio/PiP; um único decoder por vez;
 *  - só abre depois de DWELL_MS no canal e cancela tudo ao trocar;
 *  - HLS na menor qualidade, buffer curto (~6s) e sem back-buffer;
 *  - mpegts sem stash buffer e com limpeza agressiva do buffer;
 *  - sem retry/fallback em cascata: falhou, fica a arte do canal;
 *  - derruba o stream ao esconder a aba, ao sair da tela e ao ir pro player
 *    (provedores IPTV costumam limitar conexões simultâneas).
 */
export function useLivePreview(options: UseLivePreviewOptions): UseLivePreviewReturn {
  const { videoEl, mediaId, enabled } = options;

  const playing = ref(false);
  const state = ref<LivePreviewState>('idle');
  const reason = ref('');
  const playback = usePlayback();

  function dbg(message: string, extra?: unknown): void {
    if (import.meta.dev) console.info('[LivePreview]', message, extra ?? '');
  }

  let hls: Hls | null = null;
  let ts: mpegts.Player | null = null;
  /** Muda a cada teardown — descarta attach/await obsoleto. */
  let generation = 0;
  let dwellTimer: ReturnType<typeof setTimeout> | undefined;
  let stallTimer: ReturnType<typeof setTimeout> | undefined;

  function teardown(): void {
    generation += 1;
    clearTimeout(dwellTimer);
    clearTimeout(stallTimer);
    playback.reset(); // aborta o request de sessão em voo

    if (hls) {
      hls.destroy();
      hls = null;
    }
    if (ts) {
      try {
        ts.pause();
        ts.unload();
        ts.detachMediaElement();
      } catch {
        /* já desmontado */
      }
      ts.destroy();
      ts = null;
    }

    const video = videoEl.value;
    if (video) {
      video.pause();
      video.removeAttribute('src');
      video.load(); // libera o decoder
    }
    playing.value = false;
    state.value = 'idle';
  }

  /** Desiste (sem retry) e deixa só a arte do canal; guarda o motivo pro diagnóstico. */
  function fail(why: string, extra?: unknown): void {
    dbg(`falhou: ${why}`, extra);
    teardown();
    state.value = 'failed';
    reason.value = why;
  }

  function saveDataOn(): boolean {
    const connection = (navigator as Navigator & { connection?: { saveData?: boolean } }).connection;
    return connection?.saveData === true;
  }

  function schedule(): void {
    teardown();
    reason.value = '';
    const id = mediaId();
    if (!id || !enabled() || saveDataOn()) return;
    if (typeof document !== 'undefined' && document.hidden) return;

    const gen = generation;
    state.value = 'waiting';
    dwellTimer = setTimeout(() => void start(id, gen), DWELL_MS);
  }

  async function start(id: string, gen: number): Promise<void> {
    state.value = 'loading';
    const session = await playback.load(id);
    if (gen !== generation) return;
    if (!session) {
      fail('sem sessão de playback', playback.error.value);
      return;
    }

    const video = videoEl.value;
    if (!video) {
      fail('sem <video> na tela');
      return;
    }
    // Autoplay só é permitido mudo; garante pelas duas vias (atributo e propriedade).
    video.defaultMuted = true;
    video.muted = true;

    stallTimer = setTimeout(() => {
      if (gen === generation && !playing.value) fail(`sem imagem em ${STALL_MS / 1000}s`);
    }, STALL_MS);

    const { url, protocol } = session;
    dbg('abrindo', { id, protocol, url });
    const isHls = /m3u8/i.test(url);
    const isFile = protocol === 'file' || /\.(mp4|webm|mkv|ogv)(\?|#|$)/i.test(url);

    if (isFile) {
      video.src = url;
      void video.play().catch(() => undefined);
      return;
    }

    if (isHls) {
      const HlsCtor = (await import('hls.js')).default;
      if (gen !== generation) return;

      if (HlsCtor.isSupported()) {
        attachHls(video, url, HlsCtor, gen);
      } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
        video.src = url;
        void video.play().catch(() => undefined);
      } else {
        await attachMpegTs(video, url, gen);
      }
      return;
    }

    await attachMpegTs(video, url, gen);
  }

  function attachHls(video: HTMLVideoElement, url: string, HlsCtor: typeof Hls, gen: number): void {
    const instance = new HlsCtor({
      enableWorker: true,
      lowLatencyMode: false,
      startLevel: 0, // menor qualidade primeiro — a prévia é pequena
      capLevelToPlayerSize: true,
      maxBufferLength: 6,
      maxMaxBufferLength: 8,
      maxBufferSize: 8 * 1000 * 1000,
      backBufferLength: 0,
      liveSyncDurationCount: 2,
      manifestLoadingMaxRetry: 1,
      levelLoadingMaxRetry: 1,
      fragLoadingMaxRetry: 1,
    });
    hls = instance;

    instance.loadSource(url);
    instance.attachMedia(video);
    instance.on(HlsCtor.Events.MANIFEST_PARSED, () => {
      void video.play().catch(() => undefined);
    });
    instance.on(HlsCtor.Events.ERROR, (_event, data) => {
      if (gen !== generation) return;
      // Lista que não é HLS de verdade → tenta MPEG-TS uma única vez.
      if (data.details === 'manifestParsingError' || data.details === 'manifestLoadError') {
        teardownEngineOnly();
        void attachMpegTs(video, url, gen);
        return;
      }
      if (data.fatal) fail(`hls fatal: ${data.details}`, data); // sem retry: fica a arte do canal
    });
  }

  /** Troca de motor sem invalidar a geração (o teardown completo cancelaria o fallback). */
  function teardownEngineOnly(): void {
    if (hls) {
      hls.destroy();
      hls = null;
    }
  }

  async function attachMpegTs(video: HTMLVideoElement, url: string, gen: number): Promise<void> {
    const mpegtsLib = (await import('mpegts.js')).default;
    if (gen !== generation) return;
    if (!mpegtsLib.isSupported()) {
      fail('mpegts.js sem suporte neste navegador');
      return;
    }

    const player = mpegtsLib.createPlayer(
      { type: 'mse', isLive: true, url },
      {
        enableWorker: true,
        enableStashBuffer: false,
        stashInitialSize: 128,
        liveBufferLatencyChasing: false,
        autoCleanupSourceBuffer: true,
        autoCleanupMaxBackwardDuration: 6,
        autoCleanupMinBackwardDuration: 4,
      },
    );
    ts = player;

    player.on(mpegtsLib.Events.ERROR, (type, detail) => {
      if (gen === generation) fail(`mpegts erro: ${type}/${detail}`);
    });
    player.attachMediaElement(video);
    player.load();
    const result = player.play();
    if (result instanceof Promise) result.catch(() => undefined);
  }

  function onPlaying(): void {
    clearTimeout(stallTimer);
    playing.value = true;
    state.value = 'playing';
    dbg('tocando');
  }

  /** Algumas WebViews de TV não disparam `playing` com MSE — currentTime andando basta. */
  function onTimeUpdate(): void {
    if (playing.value) return;
    const video = videoEl.value;
    if (video && video.currentTime > 0) onPlaying();
  }

  function onVideoError(): void {
    // `video.load()` do próprio teardown pode gerar erro residual — só conta se havia stream.
    if (state.value === 'loading' || state.value === 'playing') {
      const code = videoEl.value?.error?.code;
      fail(`erro do <video>${code ? ` (code ${code})` : ''}`);
    }
  }

  function onVisibility(): void {
    if (document.hidden) teardown();
    else schedule();
  }

  // Trocou o canal (ou pausou/liberou): recomeça do zero com a espera.
  watch([mediaId, enabled], schedule);

  onMounted(() => {
    document.addEventListener('visibilitychange', onVisibility);
    schedule();
  });

  onBeforeUnmount(() => {
    document.removeEventListener('visibilitychange', onVisibility);
    teardown();
  });

  return { playing, state, reason, onPlaying, onTimeUpdate, onVideoError, stop: teardown };
}
