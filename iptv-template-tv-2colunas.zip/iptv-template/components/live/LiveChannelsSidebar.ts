import { computed, defineComponent, nextTick, ref, type PropType } from 'vue';
import type { Category, MediaSummary } from '~/types';
import ChannelGuide from './ChannelGuide.vue';

interface SidebarGroup {
  name: string;
  channels: MediaSummary[];
  slug: string;
  /** Total real do grupo (API) — `channels` só tem o que já foi carregado. */
  total: number;
}

/** Métodos expostos pelo sidebar para o pai controlar scroll. */
interface SidebarExposed {
  resetScroll: () => void;
  revealChannel: (id: string) => void;
  sentinel: () => HTMLElement | null;
  getScrollTop: () => number;
  setScrollTop: (top: number) => void;
  focusFirst: () => void;
  hasChannel: (id: string) => boolean;
  focusChannel: (id: string) => Promise<boolean>;
}

export default defineComponent({
  name: 'LiveChannelsSidebar',

  components: { ChannelGuide },

  props: {
    /** Canais candidatos da coluna — vindo do pai (listagem + abas especiais, já filtrados). */
    pool: { type: Array as PropType<MediaSummary[]>, required: true },
    /** Categorias TV — pra mapear nome de grupo → slug de aba. */
    categories: { type: Array as PropType<Category[]>, required: true },
    /** Aba/slug ativa (destaque dos grupos). */
    activeSlug: { type: String, required: true },
    /** Rótulo do grupo atual (topo da coluna). */
    label: { type: String, required: true },
    /** Total de canais exibido no topo. */
    count: { type: Number, required: true },
    /** Texto da busca (v-model). */
    query: { type: String, required: true },
    /** Canal selecionado na lista principal (destaque). */
    selectedId: { type: String as PropType<string | null>, default: null },
    /** Primeira página ainda carregando. */
    loading: { type: Boolean, default: false },
    /** Mensagem de erro da listagem (vazio = sem erro). */
    error: { type: String, default: '' },
  },

  emits: {
    'update:query': (_value: string): boolean => true,
    clear: (): boolean => true,
    /** Usuário escolheu um grupo — o pai troca a aba. */
    select: (slug: string): boolean => typeof slug === 'string',
    /** Guia escolheu um canal — o pai seleciona e rola a lista até ele. */
    pick: (channel: MediaSummary): boolean => !!channel,
    /** Guia clicou em uma transmissão — ir direto pro player. */
    play: (channel: MediaSummary): boolean => !!channel,
    /** Botão voltar do topo da coluna. */
    back: (): boolean => true,
    /** Canal ganhou foco/hover — o pai atualiza a prévia da direita. */
    preview: (channel: MediaSummary): boolean => !!channel,
    /** Tentar de novo após erro de carregamento. */
    retry: (): boolean => true,
  },

  setup(props, { emit, expose }) {
    const sideEl = ref<HTMLElement | null>(null);
    const sideSentinel = ref<HTMLElement | null>(null);
    const rootEl = ref<HTMLElement | null>(null);

    /** Superfície pro pai: rolagem/reset e sentinela do infinite scroll da coluna. */
    function resetScroll(): void {
      sideEl.value?.scrollTo({ top: 0 });
    }

    function getScrollTop(): number {
      return sideEl.value?.scrollTop ?? 0;
    }

    function setScrollTop(top: number): void {
      if (sideEl.value) sideEl.value.scrollTop = top;
    }

    /** Foco no primeiro item navegável da coluna (a linha do grupo, logo abaixo da busca). */
    function focusFirst(): void {
      rootEl.value?.querySelector<HTMLElement>('[data-nav="sidebar"]')?.focus({ preventScroll: true });
    }

    function hasChannel(id: string): boolean {
      return groups.value.some((group) => group.channels.some((channel) => channel.id === id));
    }

    /** Expande o grupo do canal e rola até ele. */
    async function revealChannel(id: string): Promise<HTMLElement | null> {
      const group = groups.value.find((candidate) => candidate.channels.some((channel) => channel.id === id));
      if (!group) return null;
      expanded.value.add(group.name);
      await nextTick();
      const element = sideEl.value?.querySelector<HTMLElement>(`[data-channel-id="${id}"]`) ?? null;
      element?.scrollIntoView({ block: 'center', behavior: 'auto' });
      return element;
    }

    /** Volta do player: expande o grupo, centraliza e foca o canal. */
    async function focusChannel(id: string): Promise<boolean> {
      const element = await revealChannel(id);
      if (!element) return false;
      element.focus({ preventScroll: true });
      return true;
    }

    function sentinel(): HTMLElement | null {
      return sideSentinel.value;
    }

    const exposed: SidebarExposed = { resetScroll, revealChannel: (id) => void revealChannel(id), sentinel, getScrollTop, setScrollTop, focusFirst, hasChannel, focusChannel };
    expose(exposed);

    const countFormatter = new Intl.NumberFormat('pt-BR');

    /* ── Grupos expansíveis ─────────────────────────────────────────────── */

    const expanded = ref<Set<string>>(new Set());
    const expandedGuides = ref<Set<string>>(new Set());

    /** Mapa nome → slug pra filtrar a lista principal ao clicar no grupo. */
    const slugByName = computed(() => {
      const map = new Map<string, string>();
      for (const category of props.categories) {
        map.set(category.name, category.slug);
      }
      // Canais com slug especial
      map.set('Premiere', '__premiere__');
      map.set('ESPN', '__espn__');
      map.set('SportTV', '__sportv__');
      return map;
    });

    /** Nome do grupo de um canal — separa ESPN e SportTV das demais. */
    function groupFor(channel: MediaSummary): string {
      const title = channel.title.toLowerCase();
      if (title.includes('premiere') || title.includes('premiére')) return 'Premiere';
      if (title.includes('espn')) return 'ESPN';
      if (title.includes('sportv') || title.includes('spor tv')) return 'SportTV';
      return channel.categoryName || 'Outros';
    }

    const PRIORITY = [
      'Premiere', 'ESPN', 'SportTV', 'Aberto', 'Esportes', 'Desenhos 24h', 'Notícias',
      'Variedades', 'Filmes', 'Séries', 'Infantil', 'Documentários', 'Música', 'Religioso', 'Outros',
    ];

    /** Agrupa o pool e ordena por prioridade fixa (o resto em ordem alfabética). */
    const groups = computed<SidebarGroup[]>(() => {
      const map = new Map<string, MediaSummary[]>();

      for (const channel of props.pool) {
        const name = groupFor(channel);
        const existing = map.get(name);
        if (existing) {
          existing.push(channel);
        } else {
          map.set(name, [channel]);
        }
      }

      // Categorias de TV que ainda não têm canal carregado (só a 1ª página vem do
      // servidor) também aparecem — senão HBO, Big Brother etc. só existiam em "Todos".
      const liveTotalByName = new Map<string, number>();
      for (const category of props.categories) {
        if ((category.liveCount ?? 1) <= 0) continue;
        liveTotalByName.set(category.name, category.liveCount ?? category.itemCount);
        if (!map.has(category.name)) map.set(category.name, []);
      }

      return [...map.entries()]
        .map(([name, channels]) => ({
          name,
          total: liveTotalByName.get(name) ?? channels.length,
          // Ordem alfabética dentro do grupo (o pool vem em ordem do servidor
          // + abas especiais anexadas no fim — a coluna da esquerda ficava
          // embaralhada enquanto a lista do meio estava em A–Z).
          channels: [...channels].sort((a, b) => a.title.localeCompare(b.title, 'pt-BR')),
          slug: slugByName.value.get(name) ?? '',
        }))
        .sort((a, b) => {
          const idxA = PRIORITY.indexOf(a.name);
          const idxB = PRIORITY.indexOf(b.name);
          if (idxA !== -1 && idxB !== -1) return idxA - idxB;
          if (idxA !== -1) return -1;
          if (idxB !== -1) return 1;
          return a.name.localeCompare(b.name, 'pt-BR');
        });
    });

    function isExpanded(name: string): boolean {
      return expanded.value.has(name);
    }

    /** Clica no grupo: filtra a lista (evento pro pai) e expande pra mostrar os canais. */
    function selectGroup(group: SidebarGroup): void {
      // Segundo clique no grupo aberto recolhe (e, se era o filtro ativo, volta pra "Todos").
      if (expanded.value.has(group.name)) {
        expanded.value.delete(group.name);
        if (group.slug && props.activeSlug === group.slug) emit('select', '');
        return;
      }
      expanded.value.add(group.name);
      emit('select', group.slug);
    }

    function isGuideExpanded(channelId: string): boolean {
      return expandedGuides.value.has(channelId);
    }

    function toggleGuide(channelId: string): void {
      if (expandedGuides.value.has(channelId)) {
        expandedGuides.value.delete(channelId);
      } else {
        expandedGuides.value.add(channelId);
      }
    }

    function onQueryInput(event: Event): void {
      emit('update:query', (event.target as HTMLInputElement).value);
    }

    return {
      emit,
      sideEl,
      sideSentinel,
      rootEl,
      countFormatter,
      groups,
      isExpanded,
      selectGroup,
      isGuideExpanded,
      toggleGuide,
      onQueryInput,
      resetScroll,
      revealChannel,
      sentinel,
    };
  },
});
