export interface UseLiveNavOptions {
  /** Elemento raiz da tela — âncora das queries `[data-nav]`. */
  root: Ref<HTMLElement | null>;
  /** Id do canal selecionado — alvo da seta ← saindo da prévia. */
  selectedId: () => string | null;
}

export interface UseLiveNavReturn {
  /** Handler de `keydown` da raiz (setas do teclado / controle remoto). */
  onKeydown: (event: KeyboardEvent) => void;
}

/**
 * Navegação espacial por setas da tela de TV ao vivo (2 colunas).
 * Mapeia o DOM por `data-nav` (back|search|sidebar|preview), ignora elementos
 * ocultos (grupos recolhidos ficam em `v-show`) e consome a seta mesmo sem
 * destino — assim o foco não vaza pro motor espacial global da página.
 *
 *   coluna esquerda:  [← voltar] [busca]
 *                     grupos e canais (lista única)
 *   coluna direita:   prévia + ações da prévia
 */
export function useLiveNav(options: UseLiveNavOptions): UseLiveNavReturn {
  const { root, selectedId } = options;

  function navList(kind: string): HTMLElement[] {
    const nodes = Array.from(root.value?.querySelectorAll<HTMLElement>(`[data-nav="${kind}"]`) ?? []);
    // Itens ocultos (display:none) ficam no DOM sem retângulo — não são destino.
    return nodes.filter((el) => el.getClientRects().length > 0);
  }

  function sidebarFor(id: string | null): HTMLElement | undefined {
    const list = navList('sidebar');
    return (id ? list.find((element) => element.dataset.channelId === id) : undefined) ?? list[0];
  }

  /** Rolagem instantânea — suavidade em chip fraco parece trava. */
  function focusEl(element: HTMLElement | null | undefined): void {
    if (!element) return;
    element.focus({ preventScroll: true });
    element.scrollIntoView({ block: 'nearest', behavior: 'auto' });
  }

  function onKeydown(event: KeyboardEvent): void {
    const { key } = event;
    if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(key)) return;

    const target = (event.target as HTMLElement | null)?.closest<HTMLElement>('[data-nav]');
    const kind = target?.dataset.nav;
    if (!target || !kind) return;

    const move = (element: HTMLElement | null | undefined): void => {
      event.preventDefault();
      if (element) focusEl(element);
    };

    const step = (kindName: string, delta: 1 | -1): HTMLElement | undefined => {
      const list = navList(kindName);
      return list[list.indexOf(target) + delta];
    };

    switch (kind) {
      case 'back':
        if (key === 'ArrowRight') move(navList('search')[0]);
        else if (key === 'ArrowDown') move(navList('sidebar')[0]);
        else move(null);
        break;

      case 'search': {
        // Campo de texto: ←→ movem o cursor, só saem nas pontas.
        const input = target as HTMLInputElement;
        const atStart = input.selectionStart === 0 && input.selectionEnd === 0;
        const atEnd = input.selectionStart === input.value.length;
        if (key === 'ArrowDown') move(navList('sidebar')[0]);
        else if (key === 'ArrowUp') move(navList('back')[0]);
        else if (key === 'ArrowLeft' && atStart) move(navList('back')[0]);
        else if (key === 'ArrowRight' && atEnd) move(navList('preview')[0]);
        break;
      }

      case 'sidebar':
        // ↓ no último item volta pro primeiro (wrap-around).
        if (key === 'ArrowDown') move(step('sidebar', 1) ?? navList('sidebar')[0]);
        else if (key === 'ArrowUp') move(step('sidebar', -1) ?? navList('search')[0]);
        else if (key === 'ArrowRight') move(navList('preview')[0]);
        else move(null);
        break;

      case 'preview':
        if (key === 'ArrowDown') move(step('preview', 1));
        else if (key === 'ArrowUp') move(step('preview', -1));
        else if (key === 'ArrowLeft') move(sidebarFor(selectedId()));
        else move(null);
        break;
    }
  }

  return { onKeydown };
}
